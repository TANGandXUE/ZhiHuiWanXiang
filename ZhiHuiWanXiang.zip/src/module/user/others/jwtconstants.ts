export const jwtConstants = {
    secret: 'tempTest',
};